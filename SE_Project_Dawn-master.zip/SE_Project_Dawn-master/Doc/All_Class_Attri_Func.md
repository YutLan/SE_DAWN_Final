## 实体类

| Account |
| ------- |
|         |
|         |

| Role |
| ---- |
|      |
|      |

| Role_simple |
| ----------- |
|             |
|             |

| Room |
| ---- |
|      |
|      |

| Map  |
| ---- |
|      |
|      |

| Prop |
| ---- |
|      |
|      |

| Game progress |
| ------------- |
|               |
|               |



## 边界类

| RegisterPage |
| ------------ |
|              |
|              |

| LogInPage |
| --------- |
|           |
|           |

| ChooseRoomPage |
| -------------- |
|                |
|                |

| RoomList |
| -------- |
|          |
|          |

| RoleSelectPage |
| -------------- |
|                |
|                |

| ResultPage |
| ---------- |
|            |
|            |



