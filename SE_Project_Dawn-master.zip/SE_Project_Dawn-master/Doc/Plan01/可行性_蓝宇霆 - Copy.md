 

5、 Alternative Solutions

We used to think other solutions for realize the function of Dawn. However, as a new software development team, it is difficult for us to find a way to figure out the software project. Also, we should do this project by ourselves in every part .So we don’t have alternative solution temporarily.

 

7、 Other Social Factor

 

7.1 Law Based Factors

It's exciting to set up an independent game development team or think tank for the first time. We already have some wonderful ideas and prepared to put it into action , but we should also think carefully and plan ahead for LAW factor we will face in the software development.

In addition , Our team hopes that eventually this game will help everyone relax and entertain in different situations .To achieve this goal, we should try our best to make it a non-law-violate firstly. 

 In our software development ,we will obey this rules:

(1)   The name of the game don’t contains the words of infringement, vulgarity and sensitivity.

(2)   Don’t exist malicious jump links or mandatory bullet windows in the game, which may result in loss of privacy or property or security concealment

(3)   If a game is purchased by a user, it should be clearly prompted and priced, and no false information or malicious deductions should be made.

(4)   The game can not contain other platforms to share, advertising information, as well as other third-party platforms, companies, services and other propaganda letters.

7.2  Feasibility of use

7.2.1Bug processing

There is no doubt that bug processing is a huge difficulty for all the software development. Our software will design a user feedback function on the UI interface to receive the feedback when bug occurs. Our project will be open-source and welcome to any developer to offer his wonderful ideas and offer his help. 

7.2.2 Development team

Our development team is composed of students from Shanghai Jiaotong University.We master the related skills as a Product Manager , Systems Architect ,Systems Analyst, Software Development Engineer, Project Manager. We will strain our nerve to collaborate. create a successful software.

 

8.Conclusion

After analyze all those things above，we can draw a conclusion that we can start the project at once.

 