## DAWN v1.0

Dawn is a Battle Royale Game based on Java.

It is a survival battle royal game where players gets drop off by an air plane onto a forest and they have to battle other players and try to be last one standing to win the game. The objective is to gather as much resources and weapons as soon as possible and get ready to fight with anther player.

## Supported Platforms

Client:

- Android 6.x (API level 21) or later

Server:

- Linux
- Windows
- MacOS

## License
Open-source under [Apache 2.0 license](http://www.tldrlegal.com/license/apache-license-2.0-%28apache-2.0%29).

## Bug Reporting
Please log bugs under [Issues](<https://github.com/madcpt/SE_Project_Dawn/issues>) on github.

## Developers

- [Zihan Xu](https://github.com/madcpt)
- [Chenyu Yang](https://github.com/Achronferry)
- [Yi Kuang](https://github.com/Schemeer)
- [Yuting Lan](https://github.com/YutLan)
- [Jianzhen Cao](https://github.com/FY98)

## Development Log

See: [devlog.md](./devlog.md)

## Disclaimer
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR 
OTHER DEALINGS IN THE SOFTWARE.
