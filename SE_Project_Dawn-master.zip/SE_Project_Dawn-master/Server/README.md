On server, run:

~~~shell
java GreetingServer.java
javac GreetingServer port
~~~

API Define:

