public class Player {
    private String pureIP;
    private float[] location;
    public Player(String pureIP){
        this.pureIP = pureIP;
        this.location = new float[]{0, 0};
    }
}
