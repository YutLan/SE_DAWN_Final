# Development Log
Final project for EI333 \<\<Software Engineering\>\>.

+ Plan 01 - April 7, 2019
  + [x] 可行性分析报告: 合作完成	
  
  + [x] 项目开发计划（时间\花费计划+甘特图）徐
  
  + [x] 风险列表 ：曹
  
  + [x] 词汇表:  蓝
  
  + [x] 软件需求规约：合作完成
  
    
  
+ Plan 02 - April 20, 2019
  + [x] 软件架构文档
  
  + [x] 软件设计模型
  
    
  
+ Plan 03 - May 18, 2019
  + + [ ] 用例
      + [x] Register
      + [x] JoinRoom
      + [x] **CreateRoom**
      + [x] **Prepare**
      + [x] **GameProcess**
      + [x] Login
      + [ ] SelectRole
      + [x] Move
      + [x] Attack
      + [ ] UsePros
      + [x] EndOfGame
      + [ ] **ShowResult**
  + + [x] 文档

      
  
+ Plan 04 - June 18, 2019

  + [ ] 文档
    + [ ] 软件测试计划  15 cjz
    + [ ] 软件测试总结报告 5 cjz
    + [ ] 交付清单 5 xzh
    + [ ] 用户手册（多图） 7 ky

    + [ ] 软件验收报告  7 lyt

    + [ ] 软件项目总结报告 5  ky

  + [ ] 代码
    + [ ] 实现Use_prop用例，修改role，背包等 ky、cjz
    + [ ] 完善role_simple，多角色 ycy、 lyt
    + [ ] 完善show_result ycy、xzh
    + [ ] 注释，规范代码 all
    + [ ] 游戏性能优化 all

 